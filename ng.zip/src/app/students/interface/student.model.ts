export interface Student {
    studentName: String,
    studentEmail: String,
    studentBranch: String
}