import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StudentAppService } from '../student.service';

@Component({
  selector: 'app-students',
  standalone: true,
  providers: [StudentAppService],
  imports: [CommonModule],
  templateUrl: './students.component.html',
  styleUrl: './students.component.scss'
})
export class StudentsComponent implements OnInit {

  itemData: any[] = [];

  constructor(private _studentApiService: StudentAppService) { }

  ngOnInit(): void {
    this.getStudentsList()
  }

  getStudentsList(): void {
    this._studentApiService.getList().subscribe((res: any) => {
      this.itemData = res;
    })
  }

  updateStudent(data: any): void {
    console.log(data)
  }

  deleteStudent(id: number): void {
    this._studentApiService.deleteStud(id).subscribe(
      res => {
        console.log('Student deleted successfully');
        this.getStudentsList();
      },
      error => {
        console.error('Error deleting student', error);
      }
    )
  }


}



// import { MatDialog } from '@angular/material/dialog';
// import { ModalComponent } from '../components/modal/modal.component';
// public dialog: MatDialog
// openDialog(): void {
//   const dialogRef = this.dialog.open(ModalComponent);

//   dialogRef.afterClosed().subscribe(result => {
//     console.log('The dialog was closed');
//     console.log(result);
//   });
// }